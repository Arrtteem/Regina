// Write a function to replace vowels with numbers
// Get practice with strings
// Get practice with command line
// Get practice with switch

#include <cs50.h>
#include <stdio.h>

int main(int argc, string argv[])
{
   string word[];
   //do
   //{
     word = get_string("Word: ");
   //}
   printf("%s/n", word[1]);



}
