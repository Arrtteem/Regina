#include <cs50.h>
#include <stdio.h>

int main(int arc, string argv[])

{
    printf("%c", argv[1][0]);
    printf("%c", argv[2][0]);
    printf("\n");
}
