#include <cs50.h>
#include <stdio.h>

int main(void)
{
    double z = get_double("z= ");
    do
    {
        z = n / 3 - n / 4;
    }
        while (z + n < m);
}