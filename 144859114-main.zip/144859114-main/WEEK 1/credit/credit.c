#include <cs50.h>
#include <stdio.h>

int main(void)
{
    long n = 0;
    do
    {
        n = get_long("Number: ");
    }
 while (n < 100000000000 || n < 10000000000000 || n < 100000000000000);

 int eod
}
